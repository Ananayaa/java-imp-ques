/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	    String s=sc.nextLine();
	    String[] ch=s.split(" ");
	    int[] arr=new int[ch.length];
	    for(int i=0;i<arr.length;i++){
	        arr[i]=Integer.parseInt(ch[i]);
	    }
	    for(int i=0;i<arr.length;i++){
	        for(int j=i;j<arr.length;j++){
	            ArrayList<Integer> brr=new ArrayList<>();
	            for(int k=i;k<=j;k++){
	                brr.add(arr[k]);
	            }
	            int sum=0;
	            for(int x=0;x<brr.size();x++){
	                sum+=brr.get(x);
	            }
	            if(sum==0){
	                System.out.println(brr);
	            }
	        }
	    }
	}
}

// Scanner sc = new Scanner(System.in);
// 		String st = sc.nextLine();
// 		String[] a = st.split("\\s");
// 		int[] arr = new int[a.length];
// 		for(int i=0;i<a.length;i++) {
// 			arr[i]=Integer.parseInt(a[i]);
// 		}
// 		int n=arr.length;
// 		for(int i=0;i<n;i++) {
// 			for(int j=i;j<n;j++) {
// 				ArrayList<Integer> li = new ArrayList<>();
// 				for(int k=i;k<=j;k++) {
// 					li.add(arr[k]);
// 				}
// 				int sum=0;
// 				for(int x=0;x<li.size();x++) {
// 					sum+=li.get(x);
// 				}
// 				if(sum==0) {
// 					System.out.println(li);
// 				}
// 			}
// 		}

// 	}

// }
