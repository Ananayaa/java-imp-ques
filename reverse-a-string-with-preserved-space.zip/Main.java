/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		Scanner in=new Scanner(System.in);
		String str=in.nextLine();
		String res=str;
		StringBuilder sb=new StringBuilder(str);
		sb=sb.reverse();
		String s=sb.toString();
		s=s.replaceAll(" ","");
		int j=0;
		StringBuilder ans=new StringBuilder();
		for(int i=0;i<res.length()-1;i++){
		    if(res.substring(i,i+1).equals(" ")){
		        ans.append(" ");
		    }
		    else{
		        ans.append(s.charAt(j++));
		    }
		}
		ans.append(s.charAt(s.length()-1));
		System.out.print(ans);
	}
}
