/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	//	System.out.println("Hello World");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int copy=n;
	int v=0;
	while(copy!=0){
	    copy=copy/10;
	    v++;
	}
	int sum=0;
	int c=n;
	while(c!=0){
	    int rem=c%10;
	     sum+=Math.pow(rem,v);
	    c=c/10;
	}
	if(sum==n){
	    System.out.print("true");
	}
	else{
	    System.out.print("false");
	}
	}
}
