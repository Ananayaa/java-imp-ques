/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr1=new int[n];
		for(int i=0;i<n;i++){
		    arr1[i]=sc.nextInt();
		}
		int[] arr2=new int[n];
		for(int i=0;i<n;i++){
		    arr2[i]=sc.nextInt();
		}
		int[] arr3=new int[n];
		for(int i=0;i<n;i++){
		    arr3[i]=sc.nextInt();
		}
		int target=101;
		for(int i=0;i<n;i++){
		    for(int j=0;j<n;j++){
		        for(int k=0;k<n;k++){
		            if(arr1[i]+arr2[j]+arr3[k]==target){
		                System.out.print(arr1[i]+" "+arr2[j]+" "+arr3[k]+" ");
		                break;
		            }
		        }
		    }
		}
		
	}
}
