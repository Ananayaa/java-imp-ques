/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	//	System.out.println("Hello World");
	
	Scanner sc=new Scanner(System.in);
	String str=sc.nextLine();
	String t=sc.next();
	int x=t.length();
	ArrayList<Integer> arr=new ArrayList<>();
	for(int i=0;i<str.length()-x;i++){
	    if(str.substring(i,i+x).equals(t)){
	        arr.add(i);
	    }
	}
	if(arr.size()==0){
	    arr.add(-1);
	}
	System.out.print(arr);


		


	}
}
