/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		Scanner sc = new Scanner(System.in);
		String s = sc.next();
		StringBuilder sb = new StringBuilder();
		char ch='.';
		for(int i=0;i<s.length();i++) {
			ch=s.charAt(i);
			if(Character.isLowerCase(s.charAt(i))) {
				ch = Character.toUpperCase(s.charAt(i));
			}
			if(Character.isUpperCase(s.charAt(i))) {
				ch = Character.toLowerCase(s.charAt(i));
			}
			sb.append(ch);
		}
		
		System.out.println(sb);
	}
}
