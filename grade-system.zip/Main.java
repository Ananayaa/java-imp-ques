/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	char[] keys={'D','B','A','C','B','D','A','A','A','C'};
	int n=sc.nextInt();
	char[][] arr=new char[n][10];
	for(int i=0;i<n;i++){
	    for(int j=0;j<10;j++){
	        arr[i][j]=sc.next().charAt(0);
	    }
	}
	int marks=0;
	for(int i=0;i<n;i++){
	    for(int j=0;j<10;j++){
	        if(arr[i][j]==keys[j]){
	            marks++;
	        }
	    }
	}
	System.out.print(marks);
	}
}
