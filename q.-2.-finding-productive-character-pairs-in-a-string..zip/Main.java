/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s.length()-1;i+=2){
		    if(s.substring(i,i+1).compareTo(s.substring(i+1,i+2))>0){
		        sb.append(s.charAt(i));
		    }
		    else{
		        sb.append(s.charAt(i+1));
		    }
		}
		if(s.length()%2!=0){
		    sb.append(s.length()-1);
		}
		System.out.print(sb);
	}
}
