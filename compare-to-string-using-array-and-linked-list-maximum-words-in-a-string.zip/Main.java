/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		                 //   arrayy ques 2
		System.out.println("Hello World");
		String[] arr={"hi", "hello", "pune", "hellohello","punjab" };
		String s="punjab";
		for(int i=0;i<arr.length;i++){
		    int n=arr[i].compareTo(s);
		    if(n<0){
		        System.out.print(arr[i]+" ");
		    }
		}
		                //linked list ques 2
		
  Scanner sc=new Scanner(System.in);
  int n=sc.nextInt();
  LinkedList<String> ll=new LinkedList();
  for(int i=1;i<=n;i++){
      ll.add(sc.next());
  }
  String s=sc.next();
  LinkedList<String> hy=new LinkedList<>();
  for(String i:ll){
      if(i.compareTo(s)>0){
          hy.add(i);
      }
  }
System.out.print(hy);		
                      //string array ques 3
String s="heloo my name is ananyaaa";
String[] arr=s.split(" ");
int max=0;
for(int i=0;i<arr.length-1;i++){
    if(arr[i].length()<arr[i+1].length()){
        max=arr[i+1].length();
    }
}
for(int i=0;i<arr.length;i++){
    if(arr[i].length()==max){
        System.out.print(arr[i]);
    }
}


	}
}
