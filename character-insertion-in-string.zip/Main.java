/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String s=sc.nextLine();
		String[] a=s.split(" ");
		int[] arr=new int[a.length];
		for(int i=0;i<arr.length;i++){
		    arr[i]=Integer.parseInt(a[i]);
		}
		StringBuilder sb=new StringBuilder();
		int j=0;
		for(int i=0;i<str.length();i++){
		    if(j<arr.length && arr[j]==i  ){
		        sb.append("*");
		        sb.append(str.charAt(i));
		        j++;
		    }
		    else{
		        sb.append(str.charAt(i));
		    }
		}
		System.out.print(sb);
	}
}
