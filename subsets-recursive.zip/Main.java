/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static void powerset(String s,int index,String ans){
        if(index==s.length()){
            System.out.println(ans);
            return;
        }
        
        powerset(s,index+1,ans);
        powerset(s,index+1,ans+s.charAt(index));
    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		int index=0;
		String ans="";
		powerset(s,index,ans);
	}
}
