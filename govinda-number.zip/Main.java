/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static int sum(int n){
        	int sum=0;
       
		while(n!=0){
		    int rem=n%10;
		    sum+=rem;
		    n=n/10;
		}
		return sum;
    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	
		int prime=0;
		int n=sc.nextInt();
		int sumf=sum(n);
		int temp1=n;
		
		for(int i=2;i<=n;i++){
		    while(n%i==0){
		        prime+=sum(i);
		        n/=i;
		    }
		}
		if(prime==sumf){
		    System.out.print("true");
		}
		else{
		    System.out.print("false");
		}
		
	}
}
