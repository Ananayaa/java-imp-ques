/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] arr=new int[n];
		for(int i=0;i<n;i++){
		    arr[i]=sc.nextInt();
		}
		String[] str =new String[n];
		for(int i=0;i<n;i++){
		    str[i]=Integer.toString(arr[i]);
		}
		
		Arrays.sort(str);
		String q=str[0];
		for(int i=1;i<n;i++)
		{
		    String x=q+str[i];
		    String y=str[i]+q;
		    if(Long.parseLong(x)>Long.parseLong(y)){
		        q=x;
		    }
		    else{
		        q=y;
		    }
		}
	System.out.print(q);	
	}
}
