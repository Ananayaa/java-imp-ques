/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		int[] arr={2,5,6,1,8,9};
		int[] brr=new int[arr.length];
		brr[arr.length-1]=-1;
		Stack<Integer> st=new Stack<>();
		st.push(arr[arr.length-1]);
		for(int i=arr.length-2;i>=0;i--){
		    if(st.peek()<arr[i] && st.size()>0){
		        st.pop();
		    }
		    if(st.peek()>arr[i]){
		        brr[i]=st.peek();
		        
		    }
		    else if(st.size()==0){
		        brr[i]=-1;
		    }
		    st.push(arr[i]);
		}
		
		for(int i=0;i<arr.length;i++){
		    System.out.print(brr[i]);
		}
	}
}
