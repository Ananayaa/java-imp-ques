/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	  Scanner sc=new Scanner(System.in);
	  int n=sc.nextInt();
	  int[] arr=new int[n];
	  int s=sc.nextInt();
	  for(int i=0;i<n;i++){
	      arr[i]=sc.nextInt();
	  }
	  int c=0;
	  
	  for(int i=0;i<n;i++){
	      for(int j=i;j<n;j++){
	          HashSet<Integer> you=new HashSet<>();
	          for(int k=i;k<=j;k++){
	             you.add(arr[k]);
	          }
	          if(you.size()==s){
	              c++;
	          }
	      }
	  }
	  System.out.print(c);
	}
}
