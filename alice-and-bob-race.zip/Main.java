/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] alice=new int[n];
		int[] bob=new int[n];
		for(int i=0;i<n;i++){
		    alice[i]=sc.nextInt();
		}
			for(int i=0;i<n;i++){
		    bob[i]=sc.nextInt();
		}
		int count=0;
		for(int i=0;i<n;i++){
		    int x=alice[i];
		    int y=bob[i];
		    if(x<=2*y && y<=2*x){
		        count++;
		    }
		}
		System.out.print(count);
	}
}
