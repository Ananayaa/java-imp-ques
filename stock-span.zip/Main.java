/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//stock Span
		int[] stock={100,80,60,70,80};
		int n=stock.length;
		Stack<Integer> st=new Stack<>();
		int[] price=new int[n];
		st.push(0);
		for(int i=1;i<n;i++){
		    while(st.size()>0 && stock[i]>=stock[st.peek()]){
		        st.pop();
		    }
		    if(st.size()==0){
		        price[i]=i+1;
		    }
		    else {
		        price[i]=i-st.peek();
		    }
		    st.push(i);
		}
		for(int i=0;i<n;i++){
		    System.out.println(price[i]);
		}
	}
}
