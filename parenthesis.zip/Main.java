/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		//System.out.println("Hello World");
		Stack<Character> st=new Stack<>();
		String str="while (i < n) { sum += i; i++; ]";
		for(int i=0;i<str.length();i++){
		    char ch=str.charAt(i);
		if(ch=='('||ch=='{'||ch=='[' ){
		    st.push(ch);
		}
		if(ch==')'||ch==']'||ch=='}'){
		    if(st.size()==0){
		        System.out.print("false");
		        break;
		    }
		    if(st.peek()=='(' && ch==')'||st.peek()=='[' && ch==']'||st.peek()=='{'&&ch=='}'){
		        st.pop();
		    }
		}
		    
		}
		if(st.size()==0){
		    System.out.print("true");
		}
		else{
		    System.out.print("false");
		}
	}
}
