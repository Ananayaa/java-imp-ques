/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
     static void subset(int[] arr,int index,ArrayList<ArrayList<Integer>>ans,ArrayList<Integer>temp){
        
        if(index==arr.length){
           if(temp.size()!=0){
            ans.add(new ArrayList<>(temp));
            return;
               
           }return;
        }
        subset(arr,index+1,ans,temp);
        temp.add(arr[index]);
        subset(arr,index+1,ans,temp);
        temp.remove(temp.size()-1);
        
        
    }
	public static void main(String[] args) {
	   Scanner sc=new Scanner(System.in);
	   int n=sc.nextInt();
	   int[] arr=new int[n];
	   for(int i=0;i<n;i++){
	      arr[i]=sc.nextInt(); 
	   }
	   ArrayList<ArrayList<Integer>> ans=new ArrayList<>();
	   int index=0;
	   ArrayList<Integer> temp=new ArrayList<>();
	   subset(arr,index,ans,temp);
	   System.out.print(ans);
	}
}
