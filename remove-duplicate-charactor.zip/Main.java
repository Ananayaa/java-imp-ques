/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
String str=sc.next();
StringBuilder sb=new StringBuilder();
for(int i=0;i<str.length()-1;i++){
    char ch=str.charAt(i);
    if(!str.substring(i,i+1).equals(str.substring(i+1,i+2))){
        sb.append(str.charAt(i));
    }
}
sb.append(str.charAt(str.length()-1));
System.out.println(sb.toString());
	}
}
